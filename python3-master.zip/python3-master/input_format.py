age = input("How old are you? ")
height = input(f"You're {age}? Nice!How tall are you? ")
weight = input("How much do you weight? ")
print(f"So, you're {age} old, {height} tall, and {weight} heavy.")