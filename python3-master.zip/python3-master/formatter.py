formatter = "{} {} {} {}"
print(formatter.format(1, 2, 3, 4))
print(formatter.format("one", "two", "three", "four"))
print(formatter.format(True, False, False, True))
print(formatter.format(
  
  " Try your own text 1\n",
  "Try your own text 2\n",
  "Try your own text 3\n",
  "Try your own text 4\n"
  
  ))